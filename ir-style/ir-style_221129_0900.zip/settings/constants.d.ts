export declare const classPrefix = "";
//# sourceMappingURL=constants.d.ts.map