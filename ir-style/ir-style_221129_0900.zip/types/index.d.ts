export * from "./color";
export * from "./props";
//# sourceMappingURL=index.d.ts.map