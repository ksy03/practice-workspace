declare const _default: {
    input: {
        blockElementName: string;
        toString: () => string;
    } & {
        [x: string]: `${string}--${string}`;
    } & {};
    inputNative: {
        blockElementName: string;
        toString: () => string;
    } & {
        [x: string]: `${string}--${string}`;
    } & {};
    inputSuffix: {
        blockElementName: string;
        toString: () => string;
    } & {
        [x: string]: `${string}--${string}`;
    } & {};
    inputPrefix: {
        blockElementName: string;
        toString: () => string;
    } & {
        [x: string]: `${string}--${string}`;
    } & {};
};
export default _default;
//# sourceMappingURL=input.classNames.d.ts.map