export * from "./clipboard";
//# sourceMappingURL=index.d.ts.map