interface CreateNewIconArgs {
    svg: string;
    name: string;
    masked?: boolean;
}
export declare const createCustomIcon: (...iconList: CreateNewIconArgs[]) => void;
export {};
//# sourceMappingURL=icon.d.ts.map