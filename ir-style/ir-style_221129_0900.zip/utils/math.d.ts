export declare function getMinMaxBetween(value: number, min: number, max: number): number;
//# sourceMappingURL=math.d.ts.map