export declare function getTextWidthContext(fontSize: string, fontFamily: string): {
    calculateWidth: (text: string) => number;
};
//# sourceMappingURL=size.d.ts.map