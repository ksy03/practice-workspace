export declare function get2DGenerator(height: number, width: number): Generator<{
    y: number;
    x: number;
}, void, unknown>;
//# sourceMappingURL=collection.d.ts.map