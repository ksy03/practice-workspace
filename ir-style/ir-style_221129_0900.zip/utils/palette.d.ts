export declare const Palette: {
    BIZ_NO_AUTH: string;
};
//# sourceMappingURL=palette.d.ts.map