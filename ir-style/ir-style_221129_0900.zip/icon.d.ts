export declare const createCustomIcon: () => void;
//# sourceMappingURL=icon.d.ts.map