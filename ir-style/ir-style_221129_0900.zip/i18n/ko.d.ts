import { IRStyleI18N } from './base';
declare const i18n: IRStyleI18N;
export default i18n;
//# sourceMappingURL=ko.d.ts.map