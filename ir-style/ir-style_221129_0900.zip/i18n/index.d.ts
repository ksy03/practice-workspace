import ko from "./ko";
export default ko;
//# sourceMappingURL=index.d.ts.map