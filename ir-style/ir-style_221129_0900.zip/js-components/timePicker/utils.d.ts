export declare function isValidPattern(value: string): boolean;
export declare function parseTime(value: string): {
    hour: number;
    minute: number;
};
export declare function formatTime(hour: number, minute: number): string;
//# sourceMappingURL=utils.d.ts.map