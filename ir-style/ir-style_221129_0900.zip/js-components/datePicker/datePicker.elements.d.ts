export declare const updateI18n: () => void;
declare const _default: {
    datePicker: HTMLDivElement;
    headerTitle: HTMLElement;
    contentTableTbody: HTMLTableSectionElement;
    headerPrev: HTMLButtonElement;
    headerNext: HTMLButtonElement;
    todayButton: HTMLButtonElement;
    updateI18n: () => void;
    headerNextYear: HTMLButtonElement;
    headerPrevYear: HTMLButtonElement;
};
export default _default;
//# sourceMappingURL=datePicker.elements.d.ts.map