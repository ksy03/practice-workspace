import "codemirror/addon/mode/multiplex";
import "codemirror/addon/mode/simple";
//# sourceMappingURL=mode.d.ts.map