import type { IRGrid } from '../grid';
declare function MouseCellSelector(grid: IRGrid, table: HTMLTableElement): void;
export declare function MouseCellSelectorPlugin(): typeof MouseCellSelector;
export {};
//# sourceMappingURL=cell-selector.d.ts.map