import { IRGrid } from '../grid';
declare function RowSelection(grid: IRGrid, table: HTMLTableElement): IRGrid;
export declare function RowSelectionPlugin(): typeof RowSelection;
export {};
//# sourceMappingURL=row-selection.d.ts.map