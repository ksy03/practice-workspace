import type { IRGrid } from '../grid';
declare function SingleCellDrag(grid: IRGrid, table: HTMLTableElement): void;
export declare function SingleCellDragPlugin(): typeof SingleCellDrag;
export {};
//# sourceMappingURL=single-cell-drag.d.ts.map