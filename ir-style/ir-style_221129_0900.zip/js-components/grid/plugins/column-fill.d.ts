import type { IRGrid } from '../grid';
declare function ColumnFill(grid: IRGrid, table: HTMLTableElement, contextElement: HTMLElement): IRGrid;
export declare function ColumnFillPlugin(): typeof ColumnFill;
export {};
//# sourceMappingURL=column-fill.d.ts.map