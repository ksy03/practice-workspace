import type { IRGrid } from '../grid';
export declare const DefaultKeyPlugin: () => (grid: IRGrid, _table: HTMLTableElement, context: HTMLElement) => IRGrid;
//# sourceMappingURL=default-key.d.ts.map