import type { IRGrid } from '../grid';
declare interface DragAndDropPluginArgs {
    enabledOnHeader?: boolean;
}
export declare function CellDropPlugin(args?: DragAndDropPluginArgs): (grid: IRGrid, table: HTMLTableElement) => void;
export {};
//# sourceMappingURL=cell-drop.d.ts.map