import { IRGrid } from './grid';
export declare type VirtualRenderer = ReturnType<typeof createVirtualRenderer>;
export declare const createVirtualRenderer: (grid: IRGrid, tbody: HTMLTableSectionElement) => {
    render: () => void;
};
//# sourceMappingURL=virtual.d.ts.map