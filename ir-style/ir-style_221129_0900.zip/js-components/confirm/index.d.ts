export * from "./confirm";
//# sourceMappingURL=index.d.ts.map