import { IRComponent } from "../base";
export interface IRChartArgs {
    contextElement: HTMLElement;
    title?: string;
}
export declare class IRChart extends IRComponent {
    constructor({ contextElement }: IRChartArgs);
}
//# sourceMappingURL=chart.d.ts.map