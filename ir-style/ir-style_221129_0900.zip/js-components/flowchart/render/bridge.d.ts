export default class BridgeRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
}
import NodeRenderer from "./node";
//# sourceMappingURL=bridge.d.ts.map