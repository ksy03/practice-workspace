export default class GroupRenderer extends BaseRenderer {
    constructor(data: any, icontainer: any);
}
import BaseRenderer from "./base";
//# sourceMappingURL=group.d.ts.map