export default class DirectConnectionRenderer extends ConnectionRenderer {
    constructor(data: any, icontainer: any);
    _getLabelXY(info: any): {
        x: any;
        y: any;
    };
}
import ConnectionRenderer from "./connection";
//# sourceMappingURL=direct.d.ts.map