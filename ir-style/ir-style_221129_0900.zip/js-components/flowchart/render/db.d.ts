export default class DBRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
    get circleHeight(): number;
    _getPath(): string;
}
import NodeRenderer from "./node";
//# sourceMappingURL=db.d.ts.map