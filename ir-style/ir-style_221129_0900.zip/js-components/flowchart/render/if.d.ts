export default class IfRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
    getPolygon(): string;
}
import NodeRenderer from "./node";
//# sourceMappingURL=if.d.ts.map