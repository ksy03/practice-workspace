export default class ReturnRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
}
import NodeRenderer from "./node";
//# sourceMappingURL=return.d.ts.map