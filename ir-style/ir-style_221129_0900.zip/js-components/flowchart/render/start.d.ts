export default class StartRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
}
import NodeRenderer from "./node";
//# sourceMappingURL=start.d.ts.map