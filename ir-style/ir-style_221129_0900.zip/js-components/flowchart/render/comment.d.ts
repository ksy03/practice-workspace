export default class CommentRenderer extends NodeRenderer {
    constructor(data: any, icontainer: any);
    _getPath(): string;
}
import NodeRenderer from "./node";
//# sourceMappingURL=comment.d.ts.map