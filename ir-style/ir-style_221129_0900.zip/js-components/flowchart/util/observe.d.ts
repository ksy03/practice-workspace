export class ObserverArg {
    constructor(renderObj: RenderObject, key: string, newValue: any, oldValue: any);
    renderObj: RenderObject;
    key: string;
    newValue: any;
    oldValue: any;
}
import RenderObject from "../obj/base";
//# sourceMappingURL=observe.d.ts.map