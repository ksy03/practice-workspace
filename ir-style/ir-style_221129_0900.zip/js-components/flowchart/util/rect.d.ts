export default class Rect {
    startX: number;
    startY: number;
    endX: number;
    endY: number;
    constructor(startX: number, startY: number, endX: number, endY: number);
    isContained(x: number, y: number): boolean;
}
//# sourceMappingURL=rect.d.ts.map