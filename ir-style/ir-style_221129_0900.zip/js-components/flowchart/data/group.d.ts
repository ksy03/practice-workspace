export default class GroupStyleData extends StyleData {
    'group.margin': number;
    'group.borderAlwaysAppearance': boolean;
}
import StyleData from "./styledata";
//# sourceMappingURL=group.d.ts.map