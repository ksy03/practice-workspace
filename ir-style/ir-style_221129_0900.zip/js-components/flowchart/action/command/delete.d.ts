export default class DeleteCommand extends AddCommand {
    constructor(objDataList: any, icontainer: any);
}
import AddCommand from "./add";
//# sourceMappingURL=delete.d.ts.map