export default class AddCommand extends BaseCommand {
    constructor(objDataList: {}[], icontainer: any);
    objDataList: {}[];
    undo(): AddCommand;
    redo(): AddCommand;
}
import BaseCommand from "./base";
//# sourceMappingURL=add.d.ts.map